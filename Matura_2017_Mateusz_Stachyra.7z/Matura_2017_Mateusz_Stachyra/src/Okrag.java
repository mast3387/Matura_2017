public class Okrag implements Comparable <Okrag> {
    public int y;
    public int r;
    public int x;

    public Okrag(int x, int y, int z) {
        this.y = y;
        this.r = r;
        this.x = x;
    }
    @Override
    public int compareTo(Okrag o) {
        if (this.x==o.x) {
            return this.y-o.y;
        }
        else  {
            return this.x-o.x;
        }
    }

    @Override
    public String toString() {
        return "{"+x+" "+y+" "+r+"}";
    }
}
