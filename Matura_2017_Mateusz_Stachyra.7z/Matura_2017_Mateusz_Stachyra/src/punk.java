public class punk {
    public double y;
    public double x;

    public punk(double x, double y) {
        this.y = y;
        this.x = x;
    }
}
