import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

//https://github.com/idzikdev/HighSchool/blob/master/src/main/java/matura/probna/2017/2017-PR-A2.pdf

public class zad_4  {
    public static void main(String[] args)  throws FileNotFoundException {
        List<Okrag> okregi = new ArrayList<>();
        List<punk> punkty = new ArrayList<>();
        File plik = new File("okregi");
        Scanner scanner = new Scanner(plik);
        File plik1 = new File("punkty");
        Scanner scanner1 = new Scanner(plik1);
        String temp;
        while (scanner.hasNextLine()) {
            temp = scanner.nextLine();
            okregi.add(new Okrag(Integer.valueOf(temp.split(" ")[0]),Integer.valueOf(temp.split(" ")[1]),Integer.valueOf(temp.split(" ")[2])));
        }
        scanner.close();
        while (scanner1.hasNextLine()) {
            temp = scanner1.nextLine();
            punkty.add(new punk(Double.valueOf(temp.split(" ")[0]),Double.valueOf(temp.split(" ")[1])));
        }
        scanner1.close();
        zad1(punkty);
        zad2(okregi);
        zad3(punkty);
    }

    public static void zad1 (List<punk> punkty) {
        System.out.println("zad1");
        int[] odp1 = new int [4];
        odp1[0]=0; odp1[1]=0; odp1[2]=0; odp1[3] = 0;
        for (int i = 0; i <punkty.size() ; i++) {
            if (punkty.get(i).x>0) {
                if (punkty.get(i).y>0) {
                    odp1[0]++;
                }
                else if (punkty.get(i).y<0) {
                    odp1[1]++;
                }
            }
            else if (punkty.get(i).x<0) {
                 if (punkty.get(i).y<0) {
                    odp1[2]++;
                }
                 else if (punkty.get(i).y>0) {
                    odp1[3]++;
                 }
            }
        }
        for (int i = 0; i <4 ; i++) {
            System.out.println(odp1[i]);
        }
        System.out.println();
    }
    public static void zad2 (List<Okrag> okregi) {
        System.out.println("zad2");
        Collections.sort(okregi);
        System.out.println(okregi);
        System.out.println(okregi.size());
        System.out.println();

    }

    public static void zad3 (List<punk> punkty) {
        System.out.println("zad3");
        //P = 1/2 * |xA*yB + xB*yC + xC*yA - xC*yB - xA*yC - xB*yA|
        double pole=0;
        double temp=0;
        double xA, yB, xB, yC, xC, yA=0;
        for (int i = 0; i <punkty.size(); i++) {
            xA=punkty.get(i%(punkty.size())).x;
            yA=punkty.get(i%(punkty.size())).y;
            xB=punkty.get((i+1)%(punkty.size())).x;
            yB=punkty.get((i+1)%(punkty.size())).y;
            xC=punkty.get((i+2)%(punkty.size())).x;
            yC=punkty.get((i+2)%(punkty.size())).y;
            //System.out.println((i+2)%(punkty.size()));
            temp += 1.0/2*Math.abs(xA*yB + xB*yC + xC*yA - xC*yB - xA*yC - xB*yA);
            pole+=temp;
        }
        pole/=2+0.0;
        System.out.println((int)pole);

    }


}
